##Please check the script regarding Linux Hardening & Server configuration, it may help you to configure your system automatically.##
######################################################
#!/bin/bash
#####Linux Hardening Script#####
#####Created by Sowmik Das(sowmik.das@edfenergy.com)###
#######################################################
#######################################################
HOSTNAME=`hostname`
HARD_LOG="/var/log/`hostname`_hard_log"
echo "HOSTNAME:"$HOSTNAME >>${HARD_LOG}
date '+DATE: %m/%d/%y%nTIME:%H:%M:%S' >>${HARD_LOG}
#echo -n "Please Enter Your Name: "
#read NAME
#echo "Linux Administrator:" $NAME >>${HARD_LOG}

#echo "Please Enter Project Name: "

#read PROJECT

#echo "Project Name:" $PROJECT >>${HARD_LOG}

echo "Please wait...Hardening is in progess"

######Time Zone change to BST######

rm -f /etc/localtime
ln -s /usr/share/zoneinfo/GB /etc/localtime

echo "Creating Directory Called /etc/BackupSystemFiles for Backup of critical files and files copying are in progress" >> ${HARD_LOG}

v_directory="/etc/BackupSystemFiles_"$(date +%d_%m_%Y_%H_%M_%S)

mkdir $v_directory

cd /

tar -cvf $v_directory/etc.tar etc &>/dev/null

sleep 10

echo "Files have been copied to /etc/BackupSystemFiles " >>${HARD_LOG}

######Banner#####

echo "Updating the banner in /etc/issue.net file" >> ${HARD_LOG}
echo "********************************************************************************" >/etc/issue.net

echo "* *">>/etc/issue.net

echo "*IT IS AN OFFENSE TO CONTINUE WORK WITHOUT PROPER AUTHORIZATION.*">>/etc/issue.net

echo "* *">>/etc/issue.net

echo "**************************************************** WARNING ***************************************">>/etc/issue.net

echo "*THE PROGRAM AND DATA STORED INSIDE THIS SYSTEM ARE LICENSE TO OR ARE THE PROPERTY OF EDF ENERGY CORPORATION. THIS IS A PRIVATE COMPUTING SYSTEM FOR USE ONLY BY AUTHORISED USERS. UNAUTHORISED ACCESS TO ANY PROGRAM OR DATA ON THIS SYSTEM IS NOT PERMITTED*">>/etc/issue.net


echo "* *">>/etc/issue.net

echo "********************************************************************************">>/etc/issue.net

echo "Above Banner is updated in the System " >> ${HARD_LOG}

#######motd#######

echo "Updating the banner in /etc/motd file" >> ${HARD_LOG}

touch /etc/motd
cat /etc/issue.net > /etc/motd

#####SELINUX configuration######

echo "SELINUX set to permissive mode" >>${HARD_LOG}

cd /etc/selinux

cp -p config $v_directory/config.prehard

sed -e 's/SELINUX=enforcing/SELINUX=permissive/g' config >>config1

cp -p config config.before

mv config1 config

#####Disable IPv6 on hosts file######

echo "Disable IPv6 on /etc/hosts file" >>${HARD_LOG}

cd /etc/

cp -p hosts $v_directory/hosts.prehard

sed -e 's/::1         localhost localhost.localdomain localhost6 localhost6.localdomain6/#::1         localhost localhost.localdomain localhost6 localhost6.localdomain6/g' hosts >>hosts1

cp -p hosts hosts.before

mv hosts1 hosts

######Disable ipv6######
####Create the following file so that even if the ipv6 kernel module is loaded then it will not be enabled####

touch /etc/modprobe.d/ipv6
echo "options ipv6 disable=1" > /etc/modprobe.d/ipv6

#####Update Kernel parameter on sysctl.conf file######

echo "Update Kernel parameter on /etc/sysctl.conf file" >>${HARD_LOG}

cd /etc/

cp -p sysctl.conf $v_directory/sysctl.conf.prehard

cat /home/ec2-user/RHEL_Hardening/kernel_parameter.txt > /etc/sysctl.conf

chmod 0600 /etc/sysctl.conf

######Disabling Core Dumps######

echo "Disabling Core Dumps by make an entry on /etc/security/limits.conf file" >>${HARD_LOG}

cd /etc/security/

cp -p limits.conf $v_directory/limits.conf.prehard

sed -i '/#<domain>      <type>  <item>         <value>/a*               soft    core    0' limits.conf
sed -i '/*               soft    core    0/a*               hard    core    0' limits.conf

######Now we need to enable the requirement for being a member of the wheel group in the PAM settings######

echo "Enabling the requirement for being a member of the wheel group in the PAM settings is done." >> ${HARD_LOG}

cd /etc/pam.d/

cp su $v_directory/su.prehard

sed -i '/# Uncomment the following line to require a user to be in the "wheel" group./aauth            required        pam_wheel.so use_uid root_only' su

######Set Password Expiry Time for users#########

echo "Setting Password Expiry Time for users ." >> ${HARD_LOG}

cd /etc/

cp login.defs $v_directory/login.defs.prehard

sed '/^PASS_MAX_DAYS/ c\PASS_MAX_DAYS   90' login.defs > login.defs1
sed '/^PASS_MIN_DAYS/ c\PASS_MIN_DAYS   7' login.defs1 > login.defs2

cp login.defs login.defs.before

mv login.defs2 login.defs

sed '/^PASS_MIN_LEN/ c\PASS_MIN_LEN   12' login.defs > login.defs1
sed '/^PASS_WARN_AGE/ c\PASS_WARN_AGE   7' login.defs1 > login.defs2

cp login.defs login.defs.before

mv login.defs2 login.defs

sed -i '/PASS_WARN_AGE   7/aFAIL_DELAY 4' login.defs

##edit /etc/default/useradd and edit the following lines##

cd /etc/default
cp -p useradd $v_directory/useradd.prehard
sed -e 's/INACTIVE=-1/INACTIVE=7/g' useradd >>useradd1
cp -p useradd useradd.before
mv useradd1 useradd

echo "********************************************************************************">> ${HARD_LOG}

######Password Standards######

echo "Setting Password Standards for users ." >> ${HARD_LOG}

cp -p /etc/pam.d/system-auth /etc/pam.d/system-auth-custom
rm /etc/pam.d/system-auth /etc/pam.d/system-auth-ac
ln -s /etc/pam.d/system-auth-custom /etc/pam.d/system-auth
ln -s /etc/pam.d/system-auth-custom /etc/pam.d/system-auth-ac
cp -p /etc/pam.d/password-auth /etc/pam.d/password-auth-custom
rm /etc/pam.d/password-auth /etc/pam.d/password-auth-ac
ln -s /etc/pam.d/password-auth-custom /etc/pam.d/password-auth
ln -s /etc/pam.d/password-auth-custom /etc/pam.d/password-auth-ac

cat /home/ec2-user/RHEL_Hardening/system-auth-custom > /etc/pam.d/system-auth-custom
cat /home/ec2-user/RHEL_Hardening/password-auth-custom > /etc/pam.d/password-auth-custom

#####Securing Filesystems#######
####The following file should be created in order to disable uncommon filesystem types from being used on the system by preventing their kernel modules from being loaded.#####

echo "Filesystems Securing has been done">> ${HARD_LOG}

touch /etc/modprobe.d/CIS.conf
echo "install cramfs /bin/true" > /etc/modprobe.d/CIS.conf
echo "install freevxfs /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install jffs2 /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install hfs /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install hfsplus /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install squashfs /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install ubifs /bin/true" >> /etc/modprobe.d/CIS.conf
echo "install udf /bin/true" >> /etc/modprobe.d/CIS.conf

#####ssh configuration######

echo "Configuring SSH service" >>${HARD_LOG}

cd /etc/ssh

cp -p ssh_config $v_directory/ssh_config.prehard

cp -p sshd_config $v_directory/sshd_config.prehard

sed -e 's/#PermitRootLogin yes/PermitRootLogin no/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before

mv sshd_config1 sshd_config

sed -e 's/#HostbasedAuthentication no/HostbasedAuthentication no/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before

mv sshd_config1 sshd_config

sed -e 's/#RhostsRSAAuthentication no/RhostsRSAAuthentication no/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before

mv sshd_config1 sshd_config

sed -e 's/#IgnoreRhosts yes/IgnoreRhosts yes/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before

mv sshd_config1 sshd_config

sed -e 's/#PermitEmptyPasswords no/PermitEmptyPasswords no/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before

mv sshd_config1 sshd_config

sed -e 's/#PasswordAuthentication yes/PasswordAuthentication yes/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before
mv sshd_config1 sshd_config

sed -e 's/PasswordAuthentication no/#PasswordAuthentication no/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before
mv sshd_config1 sshd_config

sed -e 's/# Ciphers and keying/Ciphers aes128-ctr,aes192-ctr,aes256-ctr/g' sshd_config >>sshd_config1

cp -p sshd_config sshd_config.before
mv sshd_config1 sshd_config

echo "Banner /etc/issue.net" >>sshd_config

echo "********************************************************************************">> ${HARD_LOG}

######Set Daemon Umask######
## Edit the umask value in file /etc/rc.d/init.d/functions##

echo "Setting the Umask value for all users is done." >>${HARD_LOG}

cd /etc/rc.d/init.d/

cp -p functions $v_directory/functions.prehard

# edit the line with umask

sed -e 's/umask 022/umask 027/g' functions >>functions1

cp -p functions functions.before

mv functions1 functions

##Edit the umask value in file /etc/profile##

cd /etc/
cp -p profile $v_directory/profile.prehard
##edit the line with umask##
sed -e 's/umask 002/umask 027/g' profile >>profile1
sed -e 's/umask 022/umask 027/g' profile1 >>profile2
cp -p profile profile.before
mv profile2 profile

######Verify passwd, shadow and group file permissions#######

echo "Setting the passwd, shadow and group file permissions." >>${HARD_LOG}

cd /etc

ls -l > $v_directory/etc.files

chown root:root passwd shadow group

chmod 644 passwd group

chmod 400 shadow



#######Restrict Root Logins To System Console#######

echo "Restricting root Logins to the System Console By entry only tty1 in the file /etc/securetty" >> ${HARD_LOG}

cp -p /etc/securetty $v_directory/securetty.prehard

rm -f /etc/securetty
touch /etc/securetty
echo tty1 > /etc/securetty
chown root:root /etc/securetty
chmod 400 /etc/securetty

######Verify that no UID 0 Account exists Other than root######

echo "********************************************************************************">> ${HARD_LOG}

awk -F: '($3 == 0) { print "UID 0 Accounts are Below. Please do block if its not neccessary\n" $1 }' /etc/passwd>> ${HARD_LOG}


######network configuration files should also have their permissions tightened######

echo "Setting the network configuration files (/etc/hosts and /etc/services) permissions." >>${HARD_LOG}

chmod 444 /etc/hosts
chmod 444 /etc/services

######The standards also recommend that the ping and traceroute commands have their permissions tightened so that they are only accessible by the root user######

echo "Configuration of traceroute command and setting the ping/traceroute commands permissions." >>${HARD_LOG}

####Install traceroute rpm package####

yum install -y traceroute.x86_64
sleep 10

chmod 0500 /bin/ping
chmod 0500 /bin/ping6
chmod 0500 /bin/traceroute

######Telnet Installation######

echo "telnet command is installed now." >>${HARD_LOG}

yum install telnet* -y
sleep 10

######Securing Cron and At######

echo "Securing cron and at services." >>${HARD_LOG}

cd /etc
rm cron.deny at.deny
echo root > cron.allow
echo root > at.allow
chown root:root cron.allow at.allow
chmod 0400 cron.allow 
chmod 0400 at.allow


######Man Page Permissions restricted to prevent unauthorised changes######

echo "Man Page Permissions restricted to prevent unauthorised changes." >>${HARD_LOG}

for dir in /usr/share/man /usr/local/share/man /usr/share/doc /usr/local/share/doc
do
        if [ -d $dir ]
        then
                 find $dir -type f -exec chmod 644 {} +;
        fi
done

######Fix Various Permissions######

chmod 644 /etc/sysconfig/init
chown root:root /etc/sysconfig/init
#chmod 700 /etc/rc.d/rc.sysinit
#chown root:root /etc/rc.d/rc.sysinit
chmod 600 /etc/security/console.perms
chown root:root /etc/security/console.perms
chmod 400 /etc/securetty
chown root:root /etc/securetty
chmod 640 /etc/security/access.conf
chown root:root /etc/security/access.conf
chown root:root /etc/motd 
chmod 644 /etc/motd 
chown root:root /etc/issue.net 
chmod 644 /etc/issue.net
chmod 0600 /var/run/wtmpx

######Configure Shell Timeout######
##Create a /etc/profile.d/timeout.sh file##

echo "Configuration of Shell Timeout." >>${HARD_LOG}

cd /etc/profile.d/
touch timeout.sh
echo "TIMEOUT=900" > timeout.sh
echo "TMOUT=900" >>timeout.sh
echo "export TIMEOUT TMOUT" >>timeout.sh

##Create a /etc/profile.d/timeout.csh file##

cd /etc/profile.d/
touch timeout.csh
echo "setenv TIMEOUT 900" > timeout.csh
echo "setenv TMOUT 900" >>timeout.csh
chmod 755 /etc/profile.d/timeout.sh
chmod 755 /etc/profile.d/timeout.csh

######Correct Permissions on /etc/skel Files######

echo "Correct Permissions on /etc/skel Files.">> ${HARD_LOG}

chmod o-rwx /etc/skel/.bash*

######Create ftpusers File######

echo "Creating ftpusers File.">> ${HARD_LOG}

cat /etc/passwd | awk -F":" '{print $1" "$3}' | while read i
do
echo $i
name=`echo $i | awk -F" " '{print $1}'`
uid=`echo $i | awk -F" " '{print $2}'`
if [ "$uid" -lt "500" ]; then
  echo $name >> /etc/ftpusers
fi
done

cp -p /etc/ftpusers /etc/vsftpd.ftpusers

######NTP Configuration######

echo "NTP Configuration has been done successfully.">> ${HARD_LOG}

yum install ntp -y
sleep 10
cp -p /etc/ntp.conf $v_directory/ntp.conf.prehard
cat /home/ec2-user/RHEL_Hardening/ntp.conf > /etc/ntp.conf
touch /etc/ntp/step-tickers
echo "## List of servers used for initial synchronization." > /etc/ntp/step-tickers
echo "ntp1.aws.edfenergy.net" >> /etc/ntp/step-tickers
echo "ntp2.aws.edfenergy.net" >> /etc/ntp/step-tickers
cp -p /etc/sysconfig/ntpd $v_directory/ntpd.prehard
cat /home/ec2-user/RHEL_Hardening/ntpd > /etc/sysconfig/ntpd
chkconfig ntpd on
chkconfig ntpdate on
ntpdate -u ntp1.aws.edfenergy.net
sleep 10
systemctl stop ntpd
systemctl start ntpd
systemctl start ntpdate
##Disabling the Chrony service for permanently on ntp##
systemctl disable chronyd

#####SMTP Configuration####

echo "SMTP Configuration has been done successfully.">> ${HARD_LOG}

cp -p /etc/hosts $v_directory/hosts.prehard

echo "10.120.26.244	exchangerelay.customer.edfenergy.net	mailhost" >> /etc/hosts
cp -p /etc/postfix/main.cf $v_directory/main.cf.prehard
cat /home/ec2-user/RHEL_Hardening/main.cf > /etc/postfix/main.cf
cp -p /etc/aliases $v_directory/aliases.prehard
cat /home/ec2-user/RHEL_Hardening/aliases > /etc/aliases
newaliases
systemctl restart postfix
yum install -y mailx.x86_64
sleep 10 

#######growpart command updated on cloud-config file /etc/cloud/cloud.cfg######

#echo "growpart command updated on cloud-config file /etc/cloud/cloud.cfg">> ${HARD_LOG}
#cp -p /etc/cloud/cloud.cfg $v_directory/cloud.cfg.prehard
#echo "#cloud-config" >> /etc/cloud/cloud.cfg
#echo "runcmd:" >> /etc/cloud/cloud.cfg
#echo "- growpart /dev/xvda 1 >>/tmp/growroot-op.txt" >> /etc/cloud/cloud.cfg
#echo "- resize2fs /dev/xvda1 >>/tmp/resizerootfs-op.txt 2>&1" >> /etc/cloud/cloud.cfg

####Hostname change permanently to make an entry /etc/cloud/cloud.cfg####
echo "preserve_hostname: true" >> /etc/cloud/cloud.cfg

######Creating tsiadmin group######

echo "Creating tsiadmin group and provided sudo permission for tsiadmin group.">> ${HARD_LOG}

cp -p /etc/sudoers $v_directory/sudoers.prehard

groupadd -g 507 tsiadmin

###sudo permission for tsiadmin group###

echo "%tsiadmin	ALL=(ALL)	ALL" >> /etc/sudoers

######Direct su login permission disable######

echo "Disabling the direct su login.">> ${HARD_LOG}

cd /bin
chmod 740 su
chmod u+s su

######prerequisite packages for the McAfee VSEL installation######

echo "Prerequisite packages for the McAfee_VSEL agent are installed now.">> ${HARD_LOG}

yum -y install unzip ed net-tools bind-utils pam.x86_64 libgcc.x86_64 wget.x86_64 
sleep 20

######Installing SSM Agent on Linux######

echo "SSM Agent installation is completed.">> ${HARD_LOG}

sudo yum install -y https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent/latest/linux_amd64/amazon-ssm-agent.rpm
sleep 10

echo "********************************************************************************">> ${HARD_LOG}

echo "All the activities are done by this script has been logged into $HARD_LOG"

echo "Request you to save the log file" 
echo "#-----------------------#"
echo

echo " END OF THE SCRIPT "

echo

echo "#---------------------------------------------------------------------------#"
